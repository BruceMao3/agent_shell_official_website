# Agent Shell Protocol — Landing Page

Static landing page for the Agent Shell Protocol. No build step.

## Files

| File | Purpose |
|------|---------|
| `index.html` | Entry point. Loads React, Babel and `app.jsx`. Mounts `<App/>` into `#root`. |
| `app.jsx` | All UI code in one file. Self-contained — defines its own brand/data constants and components. |

## Run locally

Open `index.html` directly in a browser, or serve the folder over any static
HTTP server (Babel-standalone needs the file to load over `http://`/`https://`,
not `file://`):

```bash
npx serve .
# or
python3 -m http.server 8080
```

## Deploy

Drop `index.html` + `app.jsx` onto any static host (Vercel, Netlify, S3, GitHub
Pages, Cloudflare Pages). No server-side code, no build pipeline.

## Editing

The page is composed in `app.jsx` inside the `App()` function — sections render
top-to-bottom in this order:

1. `ABackdrop` — animated gradient + grid background
2. `ANav` — top navigation
3. `AHero` — headline + rotating wireframe globe
4. `AAudiences` — three audience cards (Builders / Operators / Protocol)
5. `AArchitecture` — protocol topology diagram
6. `APipeline` — animated request → receipt assembly line
7. `ACode` — TypeScript SDK code sample
8. `AEcosystem` — scrolling marquees of partner services / verifiers / portals
9. `AFooter` — site footer

Brand text, audience copy, the SDK snippet and the ecosystem partner list are
all defined as constants at the top of `app.jsx` (`BRAND`, `AUDIENCES`,
`CODE_SNIPPET`, `ECOSYSTEM_LOGOS`).

Color tokens live in the `A` object near the top of `app.jsx`.

## Production hardening (before going live)

`index.html` currently loads React and Babel from unpkg in development mode
and transpiles JSX in the browser. That's fine for review and demo, but for
production you should:

1. Swap to `react.production.min.js` / `react-dom.production.min.js`.
2. Pre-compile `app.jsx` with Babel (or migrate to Vite/Next) so the
   `@babel/standalone` script tag can be removed.
3. Self-host the Google Fonts (`Instrument Serif`, `JetBrains Mono`, `Geist`)
   if you don't want a runtime dependency on `fonts.googleapis.com`.
