// Hero wordmark — banner-strip variants (refined direction C).
// Each variant is a horizontal stripe inserted between nav and hero.
// Hero itself stays untouched.

// ── C1 · Mega stripe — full-bleed enormous wordmark ────────────
function HeroBannerC1() {
  return (
    <section style={{ position: 'relative', zIndex: 2 }}>
      <div style={{
        position: 'relative',
        padding: '36px 56px 40px',
        borderTop: `1px solid ${A.line}`,
        borderBottom: `1px solid ${A.line}`,
        background: `linear-gradient(180deg, rgba(139,92,246,0.05), transparent)`,
        overflow: 'hidden',
      }}>
        {/* faint horizontal scan line behind */}
        <div aria-hidden style={{
          position: 'absolute', left: 0, right: 0, top: '50%', height: 1,
          background: `linear-gradient(90deg, transparent, ${A.violet}, transparent)`,
          opacity: 0.35,
        }} />
        <div style={{
          fontFamily: 'var(--display)',
          fontSize: 'clamp(64px, 9.5vw, 156px)',
          fontWeight: 500,
          letterSpacing: '-0.03em',
          lineHeight: 0.92,
          textAlign: 'center',
          color: 'transparent',
          backgroundImage: A.gradTxt,
          backgroundClip: 'text',
          WebkitBackgroundClip: 'text',
          whiteSpace: 'nowrap',
          position: 'relative',
        }}>
          Agent Shell Protocol
        </div>
      </div>
      <AHero />
    </section>
  );
}

// ── C2 · Split mark with technical brackets ────────────────────
function HeroBannerC2() {
  const Divider = () => (
    <div style={{ width: 1, alignSelf: 'stretch', background: A.line2 }} />
  );
  const Stat = ({ k, v, accent }) => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, padding: '0 24px' }}>
      <span style={{ fontFamily: 'var(--mono)', fontSize: 9, letterSpacing: '0.22em', color: A.ink3 }}>
        {k}
      </span>
      <span style={{ fontFamily: 'var(--mono)', fontSize: 13, color: accent ? A.violet : A.ink, letterSpacing: '0.04em' }}>
        {v}
      </span>
    </div>
  );
  return (
    <section style={{ position: 'relative', zIndex: 2 }}>
      <div style={{
        display: 'flex', alignItems: 'stretch',
        padding: '24px 56px',
        borderTop: `1px solid ${A.line}`,
        borderBottom: `1px solid ${A.line}`,
        background: `linear-gradient(90deg, rgba(139,92,246,0.06), transparent 30%, transparent 70%, rgba(91,141,239,0.06))`,
        gap: 0,
      }}>
        <Stat k="CHAIN" v="ETH-1" />
        <Divider />
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 32px' }}>
          <div style={{
            fontFamily: 'var(--display)',
            fontSize: 'clamp(40px, 5.5vw, 80px)',
            fontWeight: 500,
            letterSpacing: '-0.02em',
            color: A.ink,
            whiteSpace: 'nowrap',
            lineHeight: 1,
          }}>
            Agent Shell <span style={{
              backgroundImage: A.gradAccent, backgroundClip: 'text',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
              fontStyle: 'italic',
            }}>Protocol</span>
          </div>
        </div>
        <Divider />
        <Stat k="VERSION" v="v2.1.0" accent />
        <Divider />
        <Stat k="STATUS" v="● MAINNET" />
      </div>
      <AHero />
    </section>
  );
}

// ── C3 · Outlined wordmark with filled focal word ──────────────
function HeroBannerC3() {
  return (
    <section style={{ position: 'relative', zIndex: 2 }}>
      <div style={{
        position: 'relative',
        padding: '40px 56px',
        borderTop: `1px solid ${A.line}`,
        borderBottom: `1px solid ${A.line}`,
        textAlign: 'center',
        overflow: 'hidden',
      }}>
        {/* radial glow centered on SHELL */}
        <div aria-hidden style={{
          position: 'absolute', inset: 0,
          background: `radial-gradient(ellipse 40% 100% at 50% 50%, rgba(139,92,246,0.18), transparent 70%)`,
        }} />
        <div style={{
          fontFamily: 'var(--display)',
          fontSize: 'clamp(56px, 8vw, 128px)',
          fontWeight: 500,
          letterSpacing: '-0.025em',
          lineHeight: 0.92,
          whiteSpace: 'nowrap',
          position: 'relative',
        }}>
          <span style={{
            color: 'transparent',
            WebkitTextStroke: `1px ${A.ink2}`,
          }}>
            Agent&nbsp;
          </span>
          <span style={{
            color: 'transparent',
            backgroundImage: A.gradTxt,
            backgroundClip: 'text',
            WebkitBackgroundClip: 'text',
            textShadow: `0 0 60px ${A.violet}88`,
          }}>
            Shell
          </span>
          <span style={{
            color: 'transparent',
            WebkitTextStroke: `1px ${A.ink2}`,
          }}>
            &nbsp;Protocol
          </span>
        </div>
      </div>
      <AHero />
    </section>
  );
}

// ── C4 · Stacked dual-line — mono kicker over display wordmark ─
function HeroBannerC4() {
  return (
    <section style={{ position: 'relative', zIndex: 2 }}>
      <div style={{
        position: 'relative',
        padding: '32px 56px 36px',
        borderTop: `1px solid ${A.line}`,
        borderBottom: `1px solid ${A.line}`,
        background: `linear-gradient(180deg, rgba(139,92,246,0.04), transparent)`,
        textAlign: 'center',
      }}>
        <div style={{
          fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: '0.5em',
          color: A.ink3, marginBottom: 18,
        }}>
          ╌╌&nbsp;&nbsp;PROTOCOL · v2.1 · MAINNET&nbsp;&nbsp;╌╌
        </div>
        <div style={{
          fontFamily: 'var(--display)',
          fontSize: 'clamp(64px, 9vw, 144px)',
          fontWeight: 500,
          letterSpacing: '-0.035em',
          lineHeight: 0.9,
          whiteSpace: 'nowrap',
          color: 'transparent',
          backgroundImage: A.gradTxt,
          backgroundClip: 'text',
          WebkitBackgroundClip: 'text',
        }}>
          Agent Shell
        </div>
      </div>
      <AHero />
    </section>
  );
}

// ── C5 · Ticker-tape — slowly scrolling marquee ────────────────
function HeroBannerC5() {
  const segment = (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 28,
      paddingRight: 28,
      fontFamily: 'var(--display)',
      fontSize: 'clamp(40px, 6vw, 84px)',
      fontWeight: 500,
      letterSpacing: '-0.02em',
      lineHeight: 1,
      whiteSpace: 'nowrap',
      color: A.ink,
    }}>
      Agent Shell Protocol
      <span style={{
        display: 'inline-block', width: 14, height: 14, borderRadius: '50%',
        background: A.gradAccent, boxShadow: `0 0 18px ${A.violet}aa`,
        verticalAlign: 'middle',
      }} />
    </span>
  );

  return (
    <section style={{ position: 'relative', zIndex: 2 }}>
      <div style={{
        position: 'relative',
        padding: '28px 0 32px',
        borderTop: `1px solid ${A.line}`,
        borderBottom: `1px solid ${A.line}`,
        background: `linear-gradient(180deg, rgba(139,92,246,0.04), transparent)`,
        overflow: 'hidden',
        maskImage: 'linear-gradient(90deg, transparent, #000 8%, #000 92%, transparent)',
        WebkitMaskImage: 'linear-gradient(90deg, transparent, #000 8%, #000 92%, transparent)',
      }}>
        <div style={{
          display: 'inline-flex',
          animation: 'marquee 32s linear infinite',
          whiteSpace: 'nowrap',
        }}>
          {Array.from({ length: 8 }).map((_, i) => <React.Fragment key={i}>{segment}</React.Fragment>)}
          {Array.from({ length: 8 }).map((_, i) => <React.Fragment key={'b' + i}>{segment}</React.Fragment>)}
        </div>
      </div>
      <AHero />
    </section>
  );
}

// ── Compose into design canvas ─────────────────────────────────
function HeroBannerOptionsApp() {
  const Frame = ({ children }) => (
    <div style={{
      position: 'relative', background: A.bg, color: A.ink,
      width: '100%', height: '100%',
      fontFamily: 'var(--sans)',
      isolation: 'isolate',
      overflow: 'hidden',
    }}>
      <ABackdrop />
      <ANav />
      {children}
    </div>
  );

  return (
    <DesignCanvas storageKey="hero-banner-options-v2">
      <DCSection id="banner" title="Hero banner — wordmark variants">
        <DCArtboard id="C1" label="C1 · Mega stripe (full-bleed huge)" width={1280} height={920}>
          <Frame><HeroBannerC1 /></Frame>
        </DCArtboard>
        <DCArtboard id="C2" label="C2 · Split with chain/version brackets" width={1280} height={880}>
          <Frame><HeroBannerC2 /></Frame>
        </DCArtboard>
        <DCArtboard id="C3" label="C3 · Outlined + glowing focal word" width={1280} height={900}>
          <Frame><HeroBannerC3 /></Frame>
        </DCArtboard>
        <DCArtboard id="C4" label="C4 · Stacked: kicker + display" width={1280} height={920}>
          <Frame><HeroBannerC4 /></Frame>
        </DCArtboard>
        <DCArtboard id="C5" label="C5 · Scrolling ticker-tape" width={1280} height={900}>
          <Frame><HeroBannerC5 /></Frame>
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

window.HeroBannerOptionsApp = HeroBannerOptionsApp;
