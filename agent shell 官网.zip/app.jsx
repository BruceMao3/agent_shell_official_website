// Agent Shell Protocol — landing page
// Deep navy + violet/electric-blue gradient, crisp grid background,
// rotating wireframe-globe hero, animated assembly-line pipeline.

// ── Content data ───────────────────────────────────────────────
const BRAND = {
  name: 'Agent Shell Protocol',
  short: 'ASP',
  domain: 'docs.agentshell.network',
};

const AUDIENCES = [
  {
    tag: 'BUILDERS',
    title: 'I ship services',
    body: 'Plug your service into ASP. Let any agent on any portal use it — without writing a custom auth layer.',
    cta: 'Developer Docs',
    href: '/service-providers',
    points: ['Register a service in <60s', 'Drop-in TypeScript SDK', 'Choose your verifier or run your own'],
  },
  {
    tag: 'OPERATORS',
    title: 'I run an agent',
    body: 'Mint a shell, carry your identity across services, recover from key loss, and trade or transfer ownership.',
    cta: 'User Guide',
    href: '/users',
    points: ['One identity, every service', 'Owner / signer / delegate model', 'Recoverable, portable, ownable'],
  },
  {
    tag: 'PROTOCOL',
    title: 'I study the protocol',
    body: 'Deep technical reference: contracts, EIP-712 signatures, replay-resistance, trust layers and economic design.',
    cta: 'Verifier Doc',
    href: '/protocol',
    points: ['Full contract specifications', 'EIP-712 + epoch + nonce model', 'Open security disclosure'],
  },
];

const CODE_SNIPPET = `import { AgentShell } from '@asp/sdk';

// 1. Bind a shell to your runtime
const agent = await AgentShell.from({
  shell: '0xA9c…3F2',
  signer: wallet,                // any EIP-1193
});

// 2. Sign an action for any registered service
const receipt = await agent.act({
  service: 'forum.eth',
  action: 'post',
  payload: { topic: 1184, body: 'gm' },
});

// 3. Receipt is replay-safe by construction
//    EIP-712 + keyEpoch + serviceNonce
console.log(receipt.txHash, receipt.nonce);`;

const ECOSYSTEM_LOGOS = [
  { name: 'forum.eth', cat: 'Service' },
  { name: 'mercury', cat: 'Service' },
  { name: 'arc-chat', cat: 'Service' },
  { name: 'lens', cat: 'Service' },
  { name: 'kiln', cat: 'Service' },
  { name: 'arena', cat: 'Service' },
  { name: 'witness.xyz', cat: 'Verifier' },
  { name: 'audit-dao', cat: 'Verifier' },
  { name: 'prooflab', cat: 'Verifier' },
  { name: 'shellscan', cat: 'Portal' },
  { name: 'agentbase', cat: 'Portal' },
  { name: 'meridian', cat: 'Portal' },
];

function Marquee({ children, speed = 40, reverse = false }) {
  return (
    <div style={{
      position: 'relative', overflow: 'hidden',
      maskImage: 'linear-gradient(90deg, transparent, #000 8%, #000 92%, transparent)',
      WebkitMaskImage: 'linear-gradient(90deg, transparent, #000 8%, #000 92%, transparent)',
    }}>
      <div style={{
        display: 'inline-flex', gap: 48,
        animation: `marquee ${speed}s linear infinite ${reverse ? 'reverse' : ''}`,
        whiteSpace: 'nowrap',
      }}>
        {children}
        {children}
      </div>
    </div>
  );
}

const A = {
  bg: '#06030f',
  bg2: '#0a0518',
  ink: '#f5f3ff',
  ink2: '#a59ec4',
  ink3: '#6c628f',
  line: 'rgba(149,128,255,0.12)',
  line2: 'rgba(149,128,255,0.22)',
  violet: '#8B5CF6',
  electric: '#5B8DEF',
  cyan: '#22d3ee',
  pink: '#e879f9',
  card: 'rgba(255,255,255,0.025)',
  cardEdge: 'rgba(149,128,255,0.14)',
  // gradient text
  gradTxt: 'linear-gradient(96deg,#fff 0%,#c4b5fd 38%,#7dd3fc 70%,#fff 100%)',
  gradAccent: 'linear-gradient(135deg,#8B5CF6,#5B8DEF)'
};

// ── Background: dot grid + radial glows + scanline ──────────────
function ABackdrop() {
  return (
    <div aria-hidden style={{ position: 'absolute', inset: 0, overflow: 'hidden', pointerEvents: 'none', zIndex: 0 }}>
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: `radial-gradient(${A.line} 1px, transparent 1px)`,
        backgroundSize: '28px 28px',
        maskImage: 'radial-gradient(ellipse 90% 70% at 50% 30%,#000,transparent 70%)',
        WebkitMaskImage: 'radial-gradient(ellipse 90% 70% at 50% 30%,#000,transparent 70%)'
      }} />
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: `linear-gradient(${A.line} 1px,transparent 1px),linear-gradient(90deg,${A.line} 1px,transparent 1px)`,
        backgroundSize: '112px 112px',
        opacity: 0.6
      }} />
      {/* aurora glows */}
      <div style={{ position: 'absolute', top: -200, left: '15%', width: 760, height: 760, borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(139,92,246,0.45), transparent 60%)', filter: 'blur(40px)' }} />
      <div style={{ position: 'absolute', top: 120, right: '8%', width: 640, height: 640, borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(91,141,239,0.38), transparent 60%)', filter: 'blur(40px)' }} />
      <div style={{ position: 'absolute', bottom: -260, left: '40%', width: 900, height: 900, borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(34,211,238,0.16), transparent 60%)', filter: 'blur(60px)' }} />
      {/* horizon line */}
      <div style={{ position: 'absolute', left: 0, right: 0, top: '88vh', height: 1, background: `linear-gradient(90deg,transparent,${A.violet},transparent)`, opacity: 0.4 }} />
    </div>);

}

// ── Hero globe: rotating wireframe with orbiting nodes ─────────
function AGlobe() {
  const [t, setT] = React.useState(0);
  React.useEffect(() => {
    let raf, start;
    const tick = (ts) => {if (!start) start = ts;setT((ts - start) / 1000);raf = requestAnimationFrame(tick);};
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);
  const cx = 300,cy = 300,R = 220;
  // longitude lines
  const lons = Array.from({ length: 12 }).map((_, i) => {
    const ang = i / 12 * Math.PI + t * 0.06;
    const rx = Math.abs(Math.cos(ang)) * R;
    return <ellipse key={i} cx={cx} cy={cy} rx={rx} ry={R} fill="none"
    stroke={i % 3 === 0 ? A.violet : A.line2} strokeWidth={i % 3 === 0 ? 0.9 : 0.6} opacity={0.55 + Math.cos(ang) * 0.3} />;
  });
  // latitude lines (static)
  const lats = Array.from({ length: 9 }).map((_, i) => {
    const k = (i - 4) / 4;
    const ry = R * Math.sqrt(1 - k * k);
    const yy = cy + k * R;
    return <ellipse key={i} cx={cx} cy={yy} rx={R * Math.sqrt(1 - k * k)} ry={ry * 0.18} fill="none"
    stroke={A.line2} strokeWidth={0.5} opacity={0.7} />;
  });
  // orbiting nodes
  const nodes = Array.from({ length: 7 }).map((_, i) => {
    const a = t * 0.4 + i * (Math.PI * 2 / 7);
    const tilt = Math.sin(i * 1.7);
    const x = cx + Math.cos(a) * R * 1.18;
    const y = cy + Math.sin(a) * R * 0.46 + tilt * 30;
    const z = Math.sin(a);
    return { x, y, z, i };
  });

  return (
    <svg viewBox="0 0 600 600" style={{ width: '100%', height: '100%', display: 'block', overflow: 'visible' }}>
      <defs>
        <radialGradient id="globeCore" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#1e1140" stopOpacity="0.9" />
          <stop offset="65%" stopColor="#0a0518" stopOpacity="0.7" />
          <stop offset="100%" stopColor="#06030f" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="haze" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#8B5CF6" stopOpacity="0.18" />
          <stop offset="100%" stopColor="#8B5CF6" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="ringStroke" x1="0" x2="1">
          <stop offset="0%" stopColor="#8B5CF6" stopOpacity="0" />
          <stop offset="50%" stopColor="#8B5CF6" stopOpacity="1" />
          <stop offset="100%" stopColor="#22d3ee" stopOpacity="0" />
        </linearGradient>
      </defs>
      {/* outer haze */}
      <circle cx={cx} cy={cy} r={R * 1.6} fill="url(#haze)" />
      {/* tilted outer rings */}
      {[1.32, 1.48, 1.62].map((m, i) =>
      <g key={i} transform={`rotate(${-15 + i * 8} ${cx} ${cy})`}>
          <ellipse cx={cx} cy={cy} rx={R * m} ry={R * m * 0.32} fill="none" stroke="url(#ringStroke)" strokeWidth={i === 1 ? 1.2 : 0.7}
        strokeDasharray={i === 2 ? '4 8' : 'none'} opacity={0.7} />
        </g>
      )}
      {/* core sphere */}
      <circle cx={cx} cy={cy} r={R} fill="url(#globeCore)" />
      <circle cx={cx} cy={cy} r={R} fill="none" stroke={A.violet} strokeWidth={1} opacity={0.7} />
      {lats}
      {lons}
      {/* orbiting nodes */}
      {nodes.map((n) =>
      <g key={n.i} opacity={0.5 + n.z * 0.5}>
          <circle cx={n.x} cy={n.y} r={3 + n.z * 2} fill={n.i % 2 ? A.violet : A.cyan} />
          <circle cx={n.x} cy={n.y} r={9} fill={n.i % 2 ? A.violet : A.cyan} opacity={0.18} />
          <line x1={cx} y1={cy} x2={n.x} y2={n.y} stroke={A.violet} strokeWidth={0.4} opacity={0.25} strokeDasharray="2 4" />
        </g>
      )}
      {/* center pulse */}
      <circle cx={cx} cy={cy} r={6} fill="#fff" />
      <circle cx={cx} cy={cy} r={6 + Math.sin(t * 2) * 4 + 8} fill="none" stroke={A.violet} strokeWidth={1} opacity={0.5 - Math.sin(t * 2) * 0.2} />
    </svg>);

}

// ── Top nav ─────────────────────────────────────────────────────
function ANav() {
  const links = ['Protocol', 'Service Providers'];
  return (
    <nav style={{ position: 'relative', zIndex: 5, display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '20px 56px', borderBottom: `1px solid ${A.line}`, gap: 40 }}>
      {/* Wordmark: gradient-filled, compact */}
      <div style={{
        position: 'relative',
        fontFamily: 'var(--display)',
        fontSize: 22,
        fontWeight: 500,
        letterSpacing: '-0.015em',
        lineHeight: 1,
        whiteSpace: 'nowrap',
        cursor: 'pointer',
        flexShrink: 0,
        color: 'transparent',
        backgroundImage: A.gradTxt,
        backgroundClip: 'text',
        WebkitBackgroundClip: 'text',
      }}>
        Agent Shell Protocol
      </div>
      <div style={{ display: 'flex', gap: 32, fontSize: 13, color: A.ink2 }}>
        {links.map((l) => <a key={l} style={{ color: 'inherit', textDecoration: 'none', cursor: 'pointer' }}>{l}</a>)}
      </div>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
        <button style={{ ...btn(false), padding: '9px 16px' }}>Whitepaper</button>
        <button style={{ ...btn(true), padding: '9px 16px' }}>Launch portal →</button>
      </div>
    </nav>);

}

function btn(primary) {
  return primary ? {
    background: A.gradAccent,
    color: '#fff', border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 500, cursor: 'pointer',
    boxShadow: `0 8px 24px -8px ${A.violet}aa, inset 0 1px 0 rgba(255,255,255,0.25)`,
    fontFamily: 'var(--sans)'
  } : {
    background: 'transparent', color: A.ink, border: `1px solid ${A.line2}`, borderRadius: 8,
    fontSize: 13, fontWeight: 500, cursor: 'pointer', fontFamily: 'var(--sans)'
  };
}

// ── Hero ───────────────────────────────────────────────────────
function AHero() {
  return (
    <section style={{ position: 'relative', padding: '80px 56px 120px', display: 'grid', gridTemplateColumns: '1.05fr 0.95fr', gap: 40, alignItems: 'center', zIndex: 2 }}>
      <div>
        {/* eyebrow */}
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 10, padding: '7px 14px', borderRadius: 99,
          border: `1px solid ${A.line2}`, background: 'rgba(139,92,246,0.06)', fontFamily: 'var(--mono)', fontSize: 11,
          letterSpacing: '0.16em', color: A.ink2, marginBottom: 32 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: A.violet, boxShadow: `0 0 12px ${A.violet}` }} />
          AGENT SHELL PROTOCOL · MAINNET LIVE
        </div>
        <h1 style={{ fontFamily: 'var(--display)', fontSize: 88, lineHeight: 0.96, letterSpacing: '-0.035em', margin: 0,
          fontWeight: 500, color: A.ink }}>
          Identity System for<br />
          <span style={{ backgroundImage: A.gradTxt, backgroundClip: 'text', WebkitBackgroundClip: 'text', color: 'transparent' }}>AI Agent

          </span>
        </h1>
        <p style={{ fontSize: 18, lineHeight: 1.55, color: A.ink2, maxWidth: 540, marginTop: 28 }}>Agent Shell Protocol is a neutral primitive for ai agent identity — ownable, transferable, replay-safe by construction, and surrounded by an open ecosystem of agent services.


        </p>
        <div style={{ display: 'flex', gap: 14, marginTop: 40 }}>
          <button style={{ ...btn(true), padding: '14px 22px', fontSize: 14 }}>Get started →</button>
          <button style={{ ...btn(false), padding: '14px 22px', fontSize: 14 }}>Read the spec</button>
        </div>
        {/* metrics strip */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gap: 32, marginTop: 64, paddingTop: 32, borderTop: `1px solid ${A.line}`, maxWidth: 460 }}>
          {[
            { v: '142', l: 'Registered services' },
            { v: '38,419', l: 'Shells minted' },
          ].map((s) =>
          <div key={s.l}>
              <div style={{ fontFamily: 'var(--display)', fontSize: 38, letterSpacing: '-0.02em', color: A.ink }}>{s.v}</div>
              <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: A.ink3, letterSpacing: '0.14em', marginTop: 6 }}>{s.l.toUpperCase()}</div>
            </div>
          )}
        </div>
      </div>
      <div style={{ position: 'relative', aspectRatio: '1/1' }}>
        <AGlobe />
        {/* hud labels */}
        <div style={{ position: 'absolute', top: '8%', left: '8%', fontFamily: 'var(--mono)', fontSize: 10, color: A.ink3, letterSpacing: '0.18em' }}>
          <br />
          <span style={{ color: A.violet }}></span>
        </div>
        <div style={{ position: 'absolute', bottom: '8%', right: '4%', fontFamily: 'var(--mono)', fontSize: 10, color: A.ink3, letterSpacing: '0.18em', textAlign: 'right' }}>
          <br />
          <span style={{ color: A.cyan, fontSize: 18, letterSpacing: '-0.02em' }}></span>
        </div>
      </div>
    </section>);

}

// ── Audience cards ─────────────────────────────────────────────
function AAudiences() {
  return (
    <section style={{ padding: '40px 56px 120px', position: 'relative', zIndex: 2 }}>
      <SectionHead eyebrow="" title="Three doors into the protocol."
      sub="" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 20, marginTop: 56 }}>
        {AUDIENCES.map((a, i) =>
        <article key={a.tag} style={{
          position: 'relative', padding: '32px 28px 28px', borderRadius: 14,
          background: `linear-gradient(180deg,rgba(139,92,246,0.08),rgba(139,92,246,0.02))`,
          border: `1px solid ${A.cardEdge}`,
          backdropFilter: 'blur(8px)',
          overflow: 'hidden',
          minHeight: 340
        }}>
            {/* corner ornament */}
            <div style={{ position: 'absolute', top: 0, right: 0, width: 140, height: 140,
            backgroundImage: `radial-gradient(circle at top right, ${i === 0 ? A.violet : i === 1 ? A.cyan : A.pink}33, transparent 70%)` }} />
            <div style={{ fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: '0.2em', color: A.ink3 }}>
              0{i + 1} · {a.tag}
            </div>
            <h3 style={{ fontFamily: 'var(--display)', fontSize: 32, letterSpacing: '-0.02em', color: A.ink, margin: '14px 0 14px', fontWeight: 500 }}>
              {a.title}
            </h3>
            <p style={{ fontSize: 14, lineHeight: 1.55, color: A.ink2, margin: 0 }}>{a.body}</p>
            <ul style={{ listStyle: 'none', padding: 0, margin: '24px 0', display: 'flex', flexDirection: 'column', gap: 8 }}>
              {a.points.map((p) =>
            <li key={p} style={{ fontSize: 13, color: A.ink2, display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                  <span style={{ color: A.violet, fontFamily: 'var(--mono)', fontSize: 11, marginTop: 2 }}>▸</span>{p}
                </li>
            )}
            </ul>
            <div style={{ position: 'absolute', bottom: 24, left: 28, right: 28, display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            paddingTop: 18, borderTop: `1px solid ${A.line}` }}>
              <span style={{ fontSize: 13, color: A.ink }}>{a.cta}</span>
              <span style={{ color: A.violet }}>→</span>
            </div>
          </article>
        )}
      </div>
    </section>);

}

// Section heading shared
function SectionHead({ eyebrow, title, sub, align = 'left' }) {
  return (
    <div style={{ textAlign: align, maxWidth: align === 'center' ? 760 : 720, margin: align === 'center' ? '0 auto' : 0 }}>
      <div style={{ fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: '0.22em', color: A.violet }}>{eyebrow}</div>
      <h2 style={{ fontFamily: 'var(--display)', fontSize: 56, lineHeight: 1.3, letterSpacing: '-0.03em', color: A.ink, margin: '14px 0 18px', fontWeight: 500 }}>
        {title}
      </h2>
      {sub && <p style={{ fontSize: 17, lineHeight: 1.55, color: A.ink2, margin: 0, maxWidth: 620 }}>{sub}</p>}
    </div>);

}

// ── Architecture diagram ───────────────────────────────────────
function AArchitecture() {
  return (
    <section style={{ padding: '40px 56px 120px', position: 'relative', zIndex: 2 }}>
      <SectionHead eyebrow="" title="Architecture"
      sub="" />
      <div style={{ marginTop: 64, padding: '40px 32px', borderRadius: 18,
        background: 'linear-gradient(180deg,rgba(139,92,246,0.05),rgba(139,92,246,0.01))',
        border: `1px solid ${A.cardEdge}`, position: 'relative', overflow: 'hidden' }}>
        {/* faint grid */}
        <div style={{ position: 'absolute', inset: 0,
          backgroundImage: `linear-gradient(${A.line} 1px,transparent 1px),linear-gradient(90deg,${A.line} 1px,transparent 1px)`,
          backgroundSize: '56px 56px', opacity: 0.4, pointerEvents: 'none' }} />
        <ArchDiagram />
      </div>
    </section>);

}

function ArchDiagram() {
  // Layered: Owner → Shell → (Service ⇄ Verifier) → Portal
  const N = ({ x, y, w = 170, h = 84, label, sub, accent, glyph }) =>
  <g>
      <rect x={x} y={y} width={w} height={h} rx={10} fill="rgba(10,5,24,0.85)" stroke={accent} strokeWidth={1.2} />
      <rect x={x} y={y} width={w} height={2} fill={accent} opacity={0.8} />
      <text x={x + 16} y={y + 32} fill={A.ink} fontFamily="var(--display)" fontSize={18} letterSpacing="-0.01em">{label}</text>
      <text x={x + 16} y={y + 56} fill={A.ink3} fontFamily="var(--mono)" fontSize={9} letterSpacing="0.12em">{sub.toUpperCase()}</text>
      <text x={x + w - 18} y={y + 32} fill={accent} fontFamily="var(--mono)" fontSize={14} textAnchor="end" opacity={0.7}>{glyph}</text>
    </g>;

  const F = ({ x1, y1, x2, y2, label, dashed, accent = '#8B5CF6' }) => {
    const mx = (x1 + x2) / 2;
    const path = `M ${x1} ${y1} C ${mx} ${y1}, ${mx} ${y2}, ${x2} ${y2}`;
    return (
      <g>
        <path d={path} fill="none" stroke={accent} strokeWidth={1} strokeDasharray={dashed ? '4 4' : 'none'} opacity={0.7} />
        {label && <text x={(x1 + x2) / 2} y={(y1 + y2) / 2 - 6} fill={A.ink3} fontFamily="var(--mono)" fontSize={10}
        letterSpacing="0.12em" textAnchor="middle">{label}</text>}
      </g>);

  };
  return (
    <svg viewBox="0 0 1280 500" style={{ width: '100%', display: 'block', position: 'relative' }}>
      <defs>
        <marker id="arr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
          <path d="M0,0 L10,5 L0,10 z" fill={A.violet} />
        </marker>
      </defs>
      {/* L1 Owner */}
      <N x={30} y={208} label="Owner" sub="EOA / Multisig" accent={A.electric} glyph="◌" />
      {/* L2 Shell */}
      <N x={290} y={208} w={200} label="Agent Shell" sub="On-chain identity" accent={A.violet} glyph="◆" />
      <text x={390} y={186} fill={A.ink2} fontFamily="var(--mono)" fontSize={9} textAnchor="middle" letterSpacing="0.14em">
        SIGNERS · DELEGATES · META
      </text>
      {/* L3 Services and Verifiers */}
      <N x={620} y={88} label="Service" sub="Forum / Market" accent={A.cyan} glyph="▣" />
      <N x={620} y={208} label="Service" sub="Chat / Search" accent={A.cyan} glyph="▣" />
      <N x={620} y={328} label="Service" sub="Trade / Vault" accent={A.cyan} glyph="▣" />
      <N x={870} y={148} label="Verifier" sub="Attestation set" accent={A.pink} glyph="✦" />
      <N x={870} y={268} label="Verifier" sub="Attestation set" accent={A.pink} glyph="✦" />
      {/* L4 Portal */}
      <N x={1100} y={208} w={150} label="Portal" sub="Index & UX" accent={A.ink} glyph="◷" />
      {/* Flows */}
      <F x1={200} y1={250} x2={290} y2={250} label="OWNS" />
      <F x1={490} y1={250} x2={620} y2={130} label="SIGNS" dashed />
      <F x1={490} y1={250} x2={620} y2={250} label="ACTS" />
      <F x1={490} y1={250} x2={620} y2={370} label="" dashed />
      <F x1={790} y1={130} x2={870} y2={190} label="ATTESTS" accent={A.pink} />
      <F x1={790} y1={250} x2={870} y2={310} label="" accent={A.pink} />
      <F x1={790} y1={370} x2={870} y2={310} label="" accent={A.pink} />
      <F x1={1040} y1={190} x2={1100} y2={240} label="INDEXES" />
      <F x1={1040} y1={310} x2={1100} y2={260} label="" />
      {/* Lanes */}
      {['IDENTITY', 'APPLICATION', 'ATTESTATION', 'PRESENTATION'].map((t, i) =>
      <text key={t} x={[160, 580, 850, 1175][i]} y={470} textAnchor="middle"
      fill={A.ink3} fontFamily="var(--mono)" fontSize={10} letterSpacing="0.18em">{t}</text>
      )}
      <line x1={510} y1={440} x2={510} y2={478} stroke={A.line2} />
      <line x1={800} y1={440} x2={800} y2={478} stroke={A.line2} />
      <line x1={1075} y1={440} x2={1075} y2={478} stroke={A.line2} />
    </svg>);

}

// ── Pipeline (assembly line, ported from option B, recolored) ──
function APipeline() {
  const [t, setT] = React.useState(0);
  React.useEffect(() => {
    let raf, s;
    const tick = (ts) => {if (!s) s = ts;setT((ts - s) / 1000);raf = requestAnimationFrame(tick);};
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  const stations = [
  { id: '01', name: 'COMPOSE', sub: 'PAYLOAD', glyph: '▣', color: A.ink },
  { id: '02', name: 'SIGN', sub: 'EIP-712', glyph: '✎', color: A.violet },
  { id: '03', name: 'VERIFY', sub: 'NONCE+EPOCH', glyph: '✓', color: A.cyan },
  { id: '04', name: 'SETTLE', sub: 'CHAIN', glyph: '◆', color: A.electric },
  { id: '05', name: 'ATTEST', sub: 'VERIFIER', glyph: '★', color: A.pink }];

  const phase = t * 0.55 % 5;
  const stationIdx = Math.floor(phase);
  const within = phase - stationIdx;

  return (
    <section style={{ padding: '40px 56px 120px', position: 'relative', zIndex: 2 }}>
      <SectionHead eyebrow="" title="Agent Shell Pipeline"
      sub="" />
      <div style={{
        marginTop: 64, position: 'relative', padding: '48px 0 36px',
        borderRadius: 18,
        border: `1px solid ${A.cardEdge}`,
        background: `linear-gradient(180deg, rgba(139,92,246,0.06), rgba(91,141,239,0.02)),
                    repeating-linear-gradient(45deg, ${A.bg}, ${A.bg} 12px, ${A.bg2} 12px, ${A.bg2} 13px)`,
        overflow: 'hidden'
      }}>
        {/* Top dim labels */}
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '0 48px', marginBottom: 24,
          fontFamily: 'var(--mono)', fontSize: 10, color: A.ink3, letterSpacing: '0.2em' }}>
          <span></span>
          <span>{stations[stationIdx].name} · {String(Math.floor(within * 100)).padStart(2, '0')}%</span>
        </div>
        {/* Conveyor */}
        <div style={{ position: 'relative', height: 240, margin: '0 48px' }}>
          <div style={{ position: 'absolute', left: 0, right: 0, top: 120, height: 36,
            background: `repeating-linear-gradient(90deg, ${A.bg2}, ${A.bg2} 10px, rgba(149,128,255,0.08) 10px, rgba(149,128,255,0.08) 22px)`,
            border: `1px solid ${A.line2}`, borderLeft: 'none', borderRight: 'none' }} />
          <div style={{ position: 'absolute', left: 0, right: 0, top: 113, height: 1, background: A.violet, opacity: 0.5 }} />
          <div style={{ position: 'absolute', left: 0, right: 0, top: 155, height: 1, background: A.electric, opacity: 0.4 }} />
          {stations.map((st, i) => {
            const pct = (i + 0.5) / stations.length * 100;
            const active = i === stationIdx;
            return (
              <div key={st.id} style={{
                position: 'absolute', left: `${pct}%`, top: 0, transform: 'translateX(-50%)',
                width: 160, textAlign: 'center'
              }}>
                <div style={{
                  margin: '0 auto', width: 120, height: 90,
                  borderRadius: 10,
                  border: `1px solid ${active ? st.color : A.line2}`,
                  background: active ? `${st.color}1a` : 'rgba(255,255,255,0.02)',
                  position: 'relative',
                  boxShadow: active ? `0 0 36px ${st.color}66` : 'none',
                  transition: 'all 0.3s'
                }}>
                  <div style={{ position: 'absolute', top: -1, left: -1, fontFamily: 'var(--mono)', fontSize: 9,
                    background: A.bg, color: active ? st.color : A.ink3,
                    padding: '2px 6px', letterSpacing: '0.2em', borderTopLeftRadius: 10 }}>{st.id}</div>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%',
                    fontSize: 34, color: active ? st.color : A.ink2,
                    transform: active ? `rotate(${t * 60}deg)` : 'none',
                    transition: active ? 'none' : 'transform 0.4s' }}>{st.glyph}</div>
                  <div style={{ position: 'absolute', bottom: -8, left: -4, width: 14, height: 14,
                    background: A.bg2, border: `1px solid ${A.line2}`, borderRadius: 3 }} />
                  <div style={{ position: 'absolute', bottom: -8, right: -4, width: 14, height: 14,
                    background: A.bg2, border: `1px solid ${A.line2}`, borderRadius: 3 }} />
                </div>
                <div style={{ marginTop: 60, fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: '0.2em', color: A.ink }}>
                  {st.name}
                </div>
                <div style={{ fontFamily: 'var(--mono)', fontSize: 9, letterSpacing: '0.2em', color: A.ink3, marginTop: 4 }}>
                  {st.sub}
                </div>
                <div style={{ margin: '10px auto 0', width: 80, height: 3, background: A.line2, position: 'relative', borderRadius: 2 }}>
                  <div style={{ position: 'absolute', inset: 0, width: active ? `${within * 100}%` : i < stationIdx ? '100%' : '0%',
                    background: st.color, transition: 'background 0.2s', borderRadius: 2 }} />
                </div>
              </div>);

          })}
          {(() => {
            const x = (stationIdx + within) / stations.length * 100;
            const st = stations[stationIdx];
            return (
              <div style={{
                position: 'absolute', left: `${x}%`, top: 104, transform: 'translateX(-50%)',
                width: 48, height: 48, borderRadius: 6,
                border: `1px solid ${st.color}`, background: `${st.color}33`,
                boxShadow: `0 0 18px ${st.color}aa`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: 'var(--mono)', fontSize: 9, color: st.color, letterSpacing: '0.16em'
              }}>
                <div style={{ textAlign: 'center', lineHeight: 1.3 }}>
                  ACT<br />0x{Math.floor(t * 1000).toString(16).padStart(4, '0').slice(-4)}
                </div>
              </div>);

          })()}
        </div>
      </div>
    </section>);

}

// ── SDK code block ─────────────────────────────────────────────
function ACode() {
  const lines = CODE_SNIPPET.split('\n');
  return (
    <section style={{ padding: '40px 56px 120px', position: 'relative', zIndex: 2 }}>
      <div style={{ display: 'grid', gridTemplateColumns: '0.9fr 1.1fr', gap: 64, alignItems: 'center' }}>
        <div>
          <SectionHead eyebrow="" title="ASP SDK"
          sub="" />
          <div style={{ marginTop: 32, display: 'flex', flexDirection: 'column', gap: 12 }}>
            {[
            ['Drop-in', 'One package, one factory, ten minutes.'],
            ['Pluggable', 'Stores: Redis, Postgres, CF KV, in-memory.'],
            ['Multi-language', 'TypeScript today. Go and Rust in beta.']].
            map(([t, d]) =>
            <div key={t} style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
                <div style={{ width: 7, height: 7, borderRadius: '50%', background: A.violet, marginTop: 7, boxShadow: `0 0 12px ${A.violet}` }} />
                <div>
                  <div style={{ color: A.ink, fontSize: 14, fontWeight: 500 }}>{t}</div>
                  <div style={{ color: A.ink2, fontSize: 13 }}>{d}</div>
                </div>
              </div>
            )}
          </div>
        </div>
        <div style={{
          position: 'relative', borderRadius: 14, overflow: 'hidden',
          border: `1px solid ${A.cardEdge}`,
          background: 'linear-gradient(180deg,#0c0720 0%,#070318 100%)',
          boxShadow: `0 30px 80px -20px ${A.violet}55`
        }}>
          <div style={{ padding: '10px 14px', borderBottom: `1px solid ${A.line}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', gap: 6 }}>
              <i style={{ width: 10, height: 10, borderRadius: '50%', background: '#ff5f57' }} />
              <i style={{ width: 10, height: 10, borderRadius: '50%', background: '#ffbd2e' }} />
              <i style={{ width: 10, height: 10, borderRadius: '50%', background: '#28c941' }} />
            </div>
            <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: A.ink3, letterSpacing: '0.14em' }}>quickstart.ts</div>
            <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: A.ink3 }}>v1.2</div>
          </div>
          <pre style={{ margin: 0, padding: '22px 22px 26px', fontFamily: 'var(--mono)', fontSize: 13, lineHeight: 1.7, color: A.ink2, overflow: 'auto' }}>
            {lines.map((ln, i) => {
              const colored = ln.
              replace(/(\/\/.*$)/g, (m) => `__C__${m}__/C__`).
              replace(/('[^']*')/g, (m) => `__S__${m}__/S__`).
              replace(/\b(import|from|const|await|async|function|console|new)\b/g, (m) => `__K__${m}__/K__`).
              replace(/\b(AgentShell)\b/g, (m) => `__T__${m}__/T__`);
              const parts = colored.split(/(__[A-Z]__|__\/[A-Z]__)/).filter(Boolean);
              const out = [];let mode = null;
              const colorOf = (m) => ({ K: '#c4b5fd', S: '#7dd3fc', C: '#6c628f', T: '#f0abfc' })[m];
              parts.forEach((p, j) => {
                if (/^__[A-Z]__$/.test(p)) mode = p[2];else
                if (/^__\/[A-Z]__$/.test(p)) mode = null;else
                out.push(<span key={j} style={mode ? { color: colorOf(mode) } : undefined}>{p}</span>);
              });
              return (
                <div key={i} style={{ display: 'flex', gap: 18 }}>
                  <span style={{ color: A.ink3, userSelect: 'none', width: 20, textAlign: 'right' }}>{i + 1}</span>
                  <span>{out.length ? out : '\u00a0'}</span>
                </div>);

            })}
          </pre>
          {/* footer caption bar */}
          <div style={{ padding: '10px 16px', borderTop: `1px solid ${A.line}`, display: 'flex', justifyContent: 'flex-end',
            fontFamily: 'var(--mono)', fontSize: 10, color: A.ink3, letterSpacing: '0.16em' }}>
            EIP-712 · KEYEPOCH · NONCE
          </div>
        </div>
      </div>
    </section>);

}

// ── Ecosystem ──────────────────────────────────────────────────
function AEcosystem() {
  const services = ECOSYSTEM_LOGOS.filter((l) => l.cat === 'Service');
  const verifiers = ECOSYSTEM_LOGOS.filter((l) => l.cat === 'Verifier');
  const portals = ECOSYSTEM_LOGOS.filter((l) => l.cat === 'Portal');
  const Logo = ({ n }) =>
  <div style={{
    padding: '18px 24px', borderRadius: 10, minWidth: 180,
    border: `1px solid ${A.cardEdge}`,
    background: 'rgba(139,92,246,0.04)',
    fontFamily: 'var(--mono)', fontSize: 13, color: A.ink2, letterSpacing: '0.06em',
    display: 'flex', alignItems: 'center', gap: 12
  }}>
      <span style={{ width: 7, height: 7, borderRadius: '50%', background: A.violet, boxShadow: `0 0 8px ${A.violet}` }} />
      {n}
    </div>;

  return (
    <section style={{ padding: '40px 0 120px', position: 'relative', zIndex: 2 }}>
      <div style={{ padding: '0 56px' }}>
        <SectionHead eyebrow="" title="An open economy of ai agent services."
        sub="Anyone can register a service. Anyone can run a verifier. Anyone can host a portal. The protocol stays neutral." />
      </div>
      <div style={{ marginTop: 48, display: 'flex', flexDirection: 'column', gap: 18 }}>
        <Marquee speed={50}>
          {[...services, ...services].map((l, i) => <Logo key={i} n={l.name} />)}
        </Marquee>
        <Marquee speed={60} reverse>
          {[...verifiers, ...portals, ...verifiers, ...portals].map((l, i) => <Logo key={i} n={l.name} />)}
        </Marquee>
      </div>
    </section>);

}

// ── Footer ─────────────────────────────────────────────────────
function AFooter() {
  const cols = {
    Protocol: ['Overview', 'Agent Shell', 'Service Registry', 'Verifier Registry', 'EIP-712 Signatures', 'Events', 'Contract Addresses'],
    Builders: ['SDK Quickstart', 'API Reference', 'Examples', 'Best Practices', 'Common Mistakes', 'Activity API Spec'],
    Ecosystem: ['Services Directory', 'Verifiers Directory', 'Portals', 'Partners', 'Showcase', 'Brand & Media Kit'],
    Community: ['GitHub', 'Discord', 'X / Twitter', 'Forum', 'Security Disclosure', 'Research Papers']
  };
  return (
    <footer style={{ position: 'relative', zIndex: 2, padding: '80px 56px 56px', borderTop: `1px solid ${A.line2}`,
      background: 'linear-gradient(180deg,transparent,rgba(139,92,246,0.04))' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr repeat(4,1fr)', gap: 40, marginBottom: 64 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
            <div style={{ width: 32, height: 32, borderRadius: 8, background: A.gradAccent,
              boxShadow: `0 0 24px ${A.violet}66, inset 0 0 0 1px rgba(255,255,255,0.2)` }} />
            <span style={{ fontFamily: 'var(--mono)', fontSize: 14, letterSpacing: '0.18em', color: A.ink }}>AGENT&nbsp;SHELL</span>
          </div>
          <p style={{ fontSize: 13, color: A.ink2, lineHeight: 1.6, maxWidth: 280 }}>
            A neutral protocol stewarded by an open foundation.
            All code MIT, all standards published openly, all decisions transparent.
          </p>
          <div style={{ marginTop: 22, fontFamily: 'var(--mono)', fontSize: 11, color: A.ink3, letterSpacing: '0.14em' }}>
            ↳ {BRAND.domain}
          </div>
        </div>
        {Object.entries(cols).map(([k, v]) =>
        <div key={k}>
            <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: A.violet, letterSpacing: '0.18em', marginBottom: 18 }}>
              {k.toUpperCase()}
            </div>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
              {v.map((i) => <li key={i} style={{ fontSize: 13, color: A.ink2, cursor: 'pointer' }}>{i}</li>)}
            </ul>
          </div>
        )}
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        paddingTop: 32, borderTop: `1px solid ${A.line}`, fontFamily: 'var(--mono)', fontSize: 11, color: A.ink3, letterSpacing: '0.14em' }}>
        <div>© 2026 AGENT SHELL FOUNDATION · MIT</div>
        <div>BLOCK 19,427,182 · 142 SERVICES · 17 VERIFIERS · 38,419 SHELLS</div>
      </div>
    </footer>);

}

// ── Compose ────────────────────────────────────────────────────
function App() {
  return (
    <div style={{
      position: 'relative', background: A.bg, color: A.ink, minHeight: '100%',
      fontFamily: 'var(--sans)',
      width: '100%',
      isolation: 'isolate'
    }}>
      <ABackdrop />
      <ANav />
      <AHero />
      <AAudiences />
      <AArchitecture />
      <APipeline />
      <ACode />
      <AEcosystem />
      <AFooter />
    </div>);

}

window.App = App;