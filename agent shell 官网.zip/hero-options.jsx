// Three hero-wordmark variants. Each one renders the existing AHero
// (defined in app.jsx) and overlays/inserts an "AGENT SHELL PROTOCOL"
// wordmark in a different placement. Hero design itself is untouched.

// ── Variant A · Vertical wordmark column on the left edge ─────
function HeroVariantA() {
  const letters = 'AGENTSHELLPROTOCOL'.split('');
  return (
    <section style={{ position: 'relative', padding: '80px 56px 120px 0', zIndex: 2 }}>
      {/* vertical column pinned to the left edge of the hero */}
      <div style={{
        position: 'absolute', left: 0, top: 0, bottom: 0, width: 56,
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        gap: 0, paddingTop: 100, paddingBottom: 100,
      }}>
        <div style={{
          writingMode: 'vertical-rl', transform: 'rotate(180deg)',
          fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: '0.6em',
          color: A.ink2, textTransform: 'uppercase', whiteSpace: 'nowrap',
          opacity: 0.75,
        }}>
          AGENT&nbsp;·&nbsp;SHELL&nbsp;·&nbsp;PROTOCOL
        </div>
        <div style={{ flex: 1, width: 1, marginTop: 18, marginBottom: 18,
          background: `linear-gradient(180deg, transparent, ${A.line2}, transparent)` }} />
        <div style={{
          fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '0.24em',
          color: A.ink3, writingMode: 'vertical-rl', transform: 'rotate(180deg)',
        }}>
          v2.1 · MAINNET
        </div>
      </div>
      {/* untouched hero */}
      <div style={{ paddingLeft: 56 }}>
        <AHero />
      </div>
    </section>
  );
}

// ── Variant B · Giant background watermark behind the globe ────
function HeroVariantB() {
  return (
    <section style={{ position: 'relative', zIndex: 2, overflow: 'hidden' }}>
      {/* watermark sits BEHIND the hero content (zIndex: 1 vs hero 2) */}
      <div aria-hidden style={{
        position: 'absolute', inset: 0, display: 'flex', alignItems: 'center',
        pointerEvents: 'none', zIndex: 1, overflow: 'hidden',
      }}>
        <div style={{
          fontFamily: 'var(--display)',
          fontSize: 'clamp(180px, 22vw, 340px)',
          fontWeight: 500,
          letterSpacing: '-0.04em',
          lineHeight: 0.85,
          whiteSpace: 'nowrap',
          color: 'transparent',
          backgroundImage: `linear-gradient(180deg, rgba(139,92,246,0.14), rgba(91,141,239,0.04) 65%, transparent)`,
          backgroundClip: 'text',
          WebkitBackgroundClip: 'text',
          WebkitTextStroke: `1px rgba(149,128,255,0.18)`,
          transform: 'translateX(-4%)',
          userSelect: 'none',
        }}>
          AGENT SHELL
        </div>
      </div>
      {/* corner ID tag */}
      <div style={{
        position: 'absolute', top: 32, right: 56, zIndex: 3,
        fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '0.22em',
        color: A.ink3, textAlign: 'right',
      }}>
        AGENT SHELL PROTOCOL<br />
        <span style={{ color: A.violet }}>● MAINNET · v2.1</span>
      </div>
      <AHero />
    </section>
  );
}

// ── Variant C · Wide-tracked banner stripe between nav & hero ──
function HeroVariantC() {
  return (
    <section style={{ position: 'relative', zIndex: 2 }}>
      {/* banner stripe */}
      <div style={{
        position: 'relative',
        padding: '22px 56px',
        borderBottom: `1px solid ${A.line}`,
        background: `linear-gradient(90deg, transparent, rgba(139,92,246,0.06) 30%, rgba(91,141,239,0.06) 70%, transparent)`,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 32,
      }}>
        {/* left bracket */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, flexShrink: 0 }}>
          <span style={{
            fontFamily: 'var(--mono)', fontSize: 10, color: A.ink3, letterSpacing: '0.2em',
          }}>
            [ THE
          </span>
        </div>
        {/* the wordmark itself, super-wide-tracked, centered */}
        <div style={{
          flex: 1,
          fontFamily: 'var(--display)',
          fontSize: 'clamp(28px, 3.2vw, 48px)',
          fontWeight: 500,
          letterSpacing: '0.18em',
          color: A.ink,
          textAlign: 'center',
          lineHeight: 1,
          whiteSpace: 'nowrap',
          backgroundImage: A.gradTxt,
          backgroundClip: 'text',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
        }}>
          AGENT&nbsp;&nbsp;SHELL&nbsp;&nbsp;PROTOCOL
        </div>
        {/* right bracket */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: A.violet, boxShadow: `0 0 10px ${A.violet}` }} />
          <span style={{ fontFamily: 'var(--mono)', fontSize: 10, color: A.ink3, letterSpacing: '0.2em' }}>
            v2.1 ]
          </span>
        </div>
      </div>
      <AHero />
    </section>
  );
}

// ── Compose three artboards inside design canvas ───────────────
function HeroOptionsApp() {
  // Each artboard renders the full page chrome (backdrop + nav) + a hero
  // variant. Below the hero we cut off — only the hero region is in scope.
  const Frame = ({ children }) => (
    <div style={{
      position: 'relative', background: A.bg, color: A.ink,
      width: '100%', height: '100%',
      fontFamily: 'var(--sans)',
      isolation: 'isolate',
      overflow: 'hidden',
    }}>
      <ABackdrop />
      <ANav />
      {children}
    </div>
  );

  return (
    <DesignCanvas storageKey="hero-wordmark-options">
      <DCSection id="hero-wordmark" title="AGENT SHELL PROTOCOL — Wordmark placement">
        <DCArtboard id="A" label="A · Vertical column on left edge" width={1280} height={820}>
          <Frame><HeroVariantA /></Frame>
        </DCArtboard>
        <DCArtboard id="B" label="B · Background watermark behind globe" width={1280} height={820}>
          <Frame><HeroVariantB /></Frame>
        </DCArtboard>
        <DCArtboard id="C" label="C · Wide-tracked banner stripe" width={1280} height={900}>
          <Frame><HeroVariantC /></Frame>
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

window.HeroOptionsApp = HeroOptionsApp;
